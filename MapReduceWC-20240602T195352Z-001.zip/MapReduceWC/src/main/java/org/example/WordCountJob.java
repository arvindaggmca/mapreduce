package org.example;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.util.ArrayList;
import java.util.List;

public class WordCountJob {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        //GenericOptionsParser optionsParser = new GenericOptionsParser(conf, args);
        //String[] remainingArgs = optionsParser.getRemainingArgs();

        // Error check argument number, otherwise print out correct usage.
     /*   if ((remainingArgs.length != 2) && (remainingArgs.length != 4)) {
            System.err.println("Usage:wordcount <in> <out> [-skip skipPatternFile]");
            System.exit(2);
        }*/

        Job job = Job.getInstance(conf, "word count");
        job.setJarByClass(WordCountJob.class);
        job.setMapperClass(WordCountMapper.class);
        job.setCombinerClass(WordCountReducer.class);
        job.setReducerClass(WordCountReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        job.setPartitionerClass(WordcountCustomPartitioner.class);
        job.setNumReduceTasks(3);

        // Check for if we skip anything.
       // List<String> otherArgs = new ArrayList<String>();
       /* for (int i = 0; i < remainingArgs.length; ++i) {
            if ("-skip".equals(remainingArgs[i])) {
                job.addCacheFile(new Path(remainingArgs[++i]).toUri());
                job.getConfiguration().setBoolean("wordcount.skip.patterns", true);
            } else {
                otherArgs.add(remainingArgs[i]);
            }
        }
*/
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        Path outputPath = new Path(args[1]);
       FileOutputFormat.setOutputPath(job, outputPath);
       outputPath.getFileSystem(conf).delete(outputPath);
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
